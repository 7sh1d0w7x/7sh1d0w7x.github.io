# Evidence — ulab · after

*2026-10-30 22:33 EET*

| Check | Value |
|---|---|
| permitrootlogin | `no` |
| passwordauthentication | `yes` |
| maxauthtries | `3` |
| x11forwarding | `no` |
| allowusers | `lab` |
| public listeners (LISTEN) | 4 |
| firewall policy | `drop` |
| uid 0 accounts | `root` |
| SUID binaries | 15 |
| pending updates | `0` |

**SKIPPED:** none

Raw output is in the `NN-*.txt` files. Nothing on the host was modified.
